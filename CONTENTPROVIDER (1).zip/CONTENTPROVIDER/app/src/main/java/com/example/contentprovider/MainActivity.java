package com.example.contentprovider;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText date,note;
    Button insert;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        date= (EditText) findViewById(R.id.txt_date);
        note= (EditText) findViewById(R.id.txt_note);
        insert= (Button) findViewById(R.id.btn_insert);
        insert.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.equals(insert)) {
            String sdate = date.getText().toString();
            String snote = note.getText().toString();

            ProviderDataBase dat = new ProviderDataBase(this, ProviderDataBase.DATABASE_NAME, null, 1);
            SQLiteDatabase db = dat.getWritableDatabase();
            ContentValues cv = new ContentValues();

            cv.put("date", sdate);
            cv.put("note", snote);

            ContentResolver cr = getContentResolver();
            cr.insert(Uri.parse("Content://Notes.db/notes"), cv);


            db.insert("notes", null, cv);
            db.close();
            Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show();

        }
    }
}