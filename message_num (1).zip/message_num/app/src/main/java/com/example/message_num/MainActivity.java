package com.example.message_num;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView txtnum, txtmsg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtnum=findViewById(R.id.txt_num);
        txtmsg=findViewById(R.id.txt_msg);
        Bundle b = getIntent().getBundleExtra("data");
        if(b!=null)
        {
            String s1= b.getString("num");
            String s2= b.getString("msg");
            txtnum.setText(s1);
            Toast.makeText(this, "Message Received", Toast.LENGTH_LONG).show();
            txtmsg.setText(s2);
        }
    }
}